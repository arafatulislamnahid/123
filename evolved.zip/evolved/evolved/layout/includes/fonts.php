<?php if($PAGE->theme->settings->fontselect ==1) { ?>
	<link href="//fonts.googleapis.com/css?family=Oswald" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==2) { ?>
	<link href="//fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Cabin" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==3) { ?>
	<link href="//fonts.googleapis.com/css?family=Goudy+Bookletter+1911" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Raleway:100" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==4) { ?>
	<link href="//fonts.googleapis.com/css?family=Crimson+Text" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Allerta" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==5) { ?>
	<link href="//fonts.googleapis.com/css?family=Arvo" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==6) { ?>
	<link href="//fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==7) { ?>
	<link href="//fonts.googleapis.com/css?family=Allan:bold" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Cardo" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==8) { ?>
	<link href="//fonts.googleapis.com/css?family=Lekton" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Molengo" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==9) { ?>
	<link href="//fonts.googleapis.com/css?family=Droid+Serif" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==10) { ?>
	<link href="//fonts.googleapis.com/css?family=Corben:bold" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Nobile" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==11) { ?>
	<link href="//fonts.googleapis.com/css?family=Ubuntu:bold" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==12) { ?>
	<link href="//fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==13) { ?>
	<link href="//fonts.googleapis.com/css?family=Bevan" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Pontano+Sans" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==14) { ?>
	<link href="//fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Average" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==15) { ?>
	<link href="//fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Multi" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==16) { ?>
	<link href="//fonts.googleapis.com/css?family=Sansita+One" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Kameron" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==17) { ?>
	<link href="//fonts.googleapis.com/css?family=Istok+Web" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Lora" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==18) { ?>
	<link href="//fonts.googleapis.com/css?family=Pacifico" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Arimo" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==19) { ?>
	<link href="//fonts.googleapis.com/css?family=Nixie+One" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Ledger" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==20) { ?>
	<link href="//fonts.googleapis.com/css?family=Cantata+One" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Imprima" rel="stylesheet" type="text/css">
<?php } else if($PAGE->theme->settings->fontselect==21) { ?>
	<link href="//fonts.googleapis.com/css?family=Rancho" rel="stylesheet" type="text/css">
	<link href="//fonts.googleapis.com/css?family=Gudea" rel="stylesheet" type="text/css">
<?php } ?>